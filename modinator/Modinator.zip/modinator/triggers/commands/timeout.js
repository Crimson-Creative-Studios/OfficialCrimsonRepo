const { SlashCommandBuilder } = require('discord.js')
const config = require('../../../../config.json')

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mute')
        .setDescription('Select a member and mute them')
        .addUserOption(option =>
            option
                .setName('target')
                .setDescription('The member to mute')
                .setRequired(true))
        .addIntegerOption(option =>
            option
                .setName('length')
                .setDescription('In minutes')
                .setMinValue(0)
                .setMaxValue(2628000)
                .setRequired(true))
        .addStringOption(option =>
            option
                .setName('reason')
                .setDescription('Reason for the mute')),
    async execute(interaction) {
        if (!interaction.member.roles.cache.some(r => r.name.startsWith(config.adminname))) {
            await interaction.reply({ content: "You do not have access to this command.", ephemeral: true })
        } else {
            const target = interaction.options.getMember('target')
            const reason = interaction.options.getString('reason') ?? 'No reason provided!'
            const time = interaction.options.getInteger('length')
            try {
                await target.timeout(time * 60 * 1000)
                await interaction.reply({ content: `Muting ${target.username} for reason: ${reason}` })
            } catch(err) {
                await interaction.reply({ content: `User could not be muted!`, ephemeral: true })
            }
        }
    }
}