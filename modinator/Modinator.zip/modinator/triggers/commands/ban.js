const { SlashCommandBuilder } = require('discord.js')
const config = require('../../../../config.json')

module.exports = {
	data: new SlashCommandBuilder()
		.setName('ban')
		.setDescription('Select a member and ban them')
		.addUserOption(option =>
			option
				.setName('target')
				.setDescription('The member to ban')
				.setRequired(true))
		.addStringOption(option =>
			option
				.setName('reason')
				.setDescription('Reason for the ban')),
	async execute(interaction) {
		if (!interaction.member.roles.cache.some(r => r.name.startsWith(config.adminname))) {
			await interaction.reply({ content: "You do not have access to this command.", ephemeral: true })
		} else {
			const target = interaction.options.getUser('target')
			const reason = interaction.options.getString('reason') ?? 'No reason provided!'
            try {
                await interaction.guild.members.ban(target, reason)
                await interaction.reply({ content: `Banning ${target.username} for reason: ${reason}` })
            } catch (err) {
                await interaction.reply({ content: "User could not be banned!" })
            }
		}
	}
}