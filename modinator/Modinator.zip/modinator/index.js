const tags = ["?ban", "?kick", "?mute"]

addTagCommand(tags, async (message, index) => {
    var messagestr = message.toString()
    if (index === 0) {
        const things = messagestr.split(" ")
        const target = message.mentions.members.first()
        things.shift()
        things.shift()
        const reason = things.join(" ") ?? "No reason provided"
        try {
            await message.guild.members.ban(target, reason)
            await message.reply({ content: `Banning ${target.user.username} for reason: ${reason}` })
        } catch (err) {
            await message.reply({ content: "User could not be banned!" })
        }
    } else if (index === 1) {
        const things = messagestr.split(" ")
        const target = message.mentions.members.first()
        things.shift()
        things.shift()
        const reason = things.join(" ") ?? "No reason provided"
        try {
            await message.guild.members.kick(target, reason)
            await message.reply({ content: `Kicking ${target.user.username} for reason: ${reason}` })
        } catch (err) {
            await message.reply({ content: "User could not be kicked!" })
        }
    } else if (index === 2) {
        const things = messagestr.split(" ")
        const target = message.mentions.members.first()
        var time = things[2] ?? 5
        if (typeof time !== Number) {
            try {
                time = Number(time)
            } catch(err) {
                time = 5
            }
        }
        things.shift()
        things.shift()
        things.shift()
        const reason = things.join(" ") ?? "No reason provided"
        try {
            await target.timeout(time * 60 * 1000)
            await message.reply({ content: `Muting ${target.user.username} for ${String(time)} minute(s) for reason: ${reason}` })
        } catch (err) {
            await message.reply({ content: "User could not be muted!" })
        }
    }
})