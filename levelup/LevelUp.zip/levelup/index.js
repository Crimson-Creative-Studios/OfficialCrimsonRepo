const { Events, EmbedBuilder, VoiceChannel } = require("discord.js")
const fs = require("fs")
const exConfig = require(resolvePath("config.json"))
const levelXP = []
const config = require("../config.json")

function calculateLevelXP() {
    const baseXP = 50
    const xpMultiplier = 1.25

    for (let level = 1; level <= 500; level++) {
        const xpRequired = Math.floor(baseXP * Math.pow(xpMultiplier, level - 1))
        levelXP.push(xpRequired)
    }
}

function getLevel(xp) {
    let level = 0
    while (true) {
        if (xp >= levelXP[level]) {
            level++
        } else {
            return level
        }
    }
}

calculateLevelXP()

client.on(Events.MessageCreate, async (message) => {
    const topic = message.channel.topic ?? ""
    const noXP = topic.includes("No XP")
    const isVC = message.channel instanceof VoiceChannel
    const isLong = message.toString().length > 2
    if (!message.author.bot && isLong && !noXP && !isVC) {
        if (!fs.existsSync(resolvePath(message.guild.id + ".json"))) {
            fs.writeFileSync(resolvePath(message.guild.id + ".json"), '{}')
        }
        var xpDATA
        try {
            xpDATA = JSON.parse(fs.readFileSync(resolvePath(message.guild.id + ".json"), "utf-8"))
        } catch (err) {
            console.err(err)
            return
        }
        if (xpDATA[message.author.id] === undefined) {
            xpDATA[message.author.id] = {
                xp: 0,
                level: 0,
                mul: 1,
                name: ""
            }
        }
        const userDATA = xpDATA[message.author.id]
        const randXP = (Math.floor(Math.random() * 29) + 1)
        const newXP = userDATA.xp + Math.round((randXP) * 10) / 10
        userDATA.xp = newXP
        userDATA.level = getLevel(newXP)
        userDATA.name = message.author.username
        xpDATA[message.author.id] = userDATA
        fs.writeFileSync(resolvePath(message.guild.id + ".json"), JSON.stringify(xpDATA, null, 4), "utf-8")
        try {
            const channel = client.channels.cache.get(exConfig[message.guild.id+"-logchnl"])
            const embed = new EmbedBuilder()
                .setTitle(message.guild.name)
                .setDescription(`**User:**\n${message.author.username}\n\n**XP:**\n${userDATA.xp}\n\n**Level:**\n${getLevel(userDATA.xp)}\n\n**Channel Link:**\n${message.channel.url}`)
                .setThumbnail(message.author.avatarURL({
                    size: 1024
                }))
                .setColor(0x00ffff)
            channel.send({ embeds: [embed] })
        } catch (err) { }
    }
})

const tags = ["?xpmulchng", "?levels"]

addTagCommand(tags, async (message, index) => {
    if (!fs.existsSync(resolvePath(message.guild.id + ".json"))) {
        fs.writeFileSync(resolvePath(message.guild.id + ".json"), `{}`)
    }
    if (index === 0) {
        if (!message.member.roles.cache.some(r => r.name.startsWith(config.adminname))) {
            await message.reply("You do not have access to this command.")
        } else {
            const things = message.toString().split(" ")
            const target = message.mentions.members.first()
            things.shift()
            things.shift()
            const reason = things.join(" ")
            try {
                const mul = Number(reason)
                const data = require("../Extensions/levelup/" + String(message.guild.id) + ".json")
                delete require.cache[require.resolve("../Extensions/levelup/" + String(message.guild.id) + ".json")]
                if (!data[target.id]) {
                    data[target.id] = {
                        xp: 0,
                        mul: 1
                    }
                }
                const lastmul = data[target.id].mul
                data[target.id].mul = mul
                await fs.promises.writeFile(resolvePath(message.guild.id + ".json"), JSON.stringify(data, null, 4))
                message.reply("Successfully changed XP mulitplier!")
                try {
                    const channel = client.channels.cache.get(logchnl)
                    const embed = new EmbedBuilder()
                        .setTitle(message.guild.name)
                        .setDescription(`**User:**\n${message.author.username}\n\n**Previous Multipiler:**\n${lastmul}\n\n**New Multipiler:**\n${mul}`)
                        .setThumbnail(message.author.avatarURL({
                            size: 1024
                        }))
                        .setColor(0x00ffff)
                    channel.send({ embeds: [embed] })
                } catch (err) { }
            } catch (err) {
                message.reply("Couldn't change user's XP multiplier")
                console.err(err)
            }
        }
    } else if (index === 1) {
        const { EmbedBuilder } = require("discord.js")
        const levelXP = []
        function calculateLevelXP() {
            const baseXP = 50
            const xpMultiplier = 1.25
        
            for (let level = 1; level <= 500; level++) {
                const xpRequired = Math.floor(baseXP * Math.pow(xpMultiplier, level - 1))
                levelXP.push(xpRequired)
            }
        }
        calculateLevelXP()
        var str1 = ""
        var str2 = ""
        var str3 = ""
        var str4 = ""
        for (let i = 0; i < 125; i++) {
            str1 += `${Number(i) + 1}. ${levelXP[i]} XP\n`
            str2 += `${Number(i + 125) + 1}. ${levelXP[i + 125]} XP\n`
            str3 += `${Number(i + 125 + 125) + 1}. ${levelXP[i + 125 + 125]} XP\n`
            str4 += `${Number(i + 125 + 125 + 125) + 1}. ${levelXP[i + 125 + 125 + 125]} XP\n`
        }
        const embed1 = new EmbedBuilder()
            .setTitle(`DEBUG Levels`)
            .setDescription(str1)
            .setColor(0x00ffff)
        const embed2 = new EmbedBuilder()
            .setTitle(`DEBUG Levels`)
            .setDescription(str2)
            .setColor(0x00ffff)
        const embed3 = new EmbedBuilder()
            .setTitle(`DEBUG Levels`)
            .setDescription(str3)
            .setColor(0x00ffff)
        const embed4 = new EmbedBuilder()
            .setTitle(`DEBUG Levels`)
            .setDescription(str4)
            .setColor(0x00ffff)
        message.reply({ embeds: [embed1] })
        message.reply({ embeds: [embed2] })
        message.reply({ embeds: [embed3] })
        message.reply({ embeds: [embed4] })
    }
})