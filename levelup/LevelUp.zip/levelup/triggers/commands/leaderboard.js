const { SlashCommandBuilder, EmbedBuilder } = require('discord.js')
const fs = require("fs")
const console = require("../../../../Bot/consolelogger")
const levelXP = []

function calculateLevelXP() {
    const baseXP = 50
    const xpMultiplier = 1.25

    for (let level = 1; level <= 500; level++) {
        const xpRequired = Math.floor(baseXP * Math.pow(xpMultiplier, level - 1))
        levelXP.push(xpRequired)
    }
}

function getLevel(xp) {
    let level = 0
    while (true) {
        if (xp >= levelXP[level]) {
            level++
        } else {
            return level
        }
    }
}

calculateLevelXP()

module.exports = {
    data: new SlashCommandBuilder()
        .setName("leaderboard")
        .setDescription("Check the leaderboard"),
    async execute(interaction) {
        await interaction.deferReply()
        try {
            if (!fs.existsSync("../../" + interaction.guild.id + ".json")) {
                fs.writeFileSync("../../" + interaction.guild.id + ".json", '{}')
            }
            const data = require("../../" + String(interaction.guild.id) + ".json")
            delete require.cache[require.resolve("../../" + String(interaction.guild.id) + ".json")]
            const dataArray = Object.entries(data).map(([key, value]) => ({
                player: key,
                xp: value.xp,
                level: value.level,
            }))
            dataArray.sort((a, b) => b.xp - a.xp)
            const playerKeys = dataArray.map((player) => player.player)
            const rest = playerKeys.slice(3, 10)
            var place = 4
            var str = ""
            if (playerKeys.length >= 3) {
                str += `# First\n<@${playerKeys[0]}> - Level ${getLevel(data[playerKeys[0]].xp)} (XP: ${data[playerKeys[0]].xp})\n\n## Second\n<@${playerKeys[1]}> - Level ${getLevel(data[playerKeys[1]].xp)} (XP: ${data[playerKeys[1]].xp})\n\n### Third\n<@${playerKeys[2]}> - Level ${getLevel(data[playerKeys[2]].xp)} (XP: ${data[playerKeys[2]].xp})\n\n`
            } else if (playerKeys.length === 2) {
                str += `# First\n<@${playerKeys[0]}> - Level ${getLevel(data[playerKeys[0]].xp)} (XP: ${data[playerKeys[0]].xp})\n\n## Second\n<@${playerKeys[1]}> - Level ${getLevel(data[playerKeys[1]].xp)} (XP: ${data[playerKeys[1]].xp})\n\n`
            } else if (playerKeys.length === 1) {
                str += `# First\n<@${playerKeys[0]}> - Level ${getLevel(data[playerKeys[0]].xp)} (XP: ${data[playerKeys[0]].xp})\n\n`
            } else {
                str = "No one has any XP yet!"
            }
            for (const i of rest) {
                str += `**${place}.** <@${i}> - Level ${getLevel(data[i].xp)} (XP: ${data[i].xp})\n`
                place++
            }
            const embed = new EmbedBuilder()
                .setTitle(interaction.guild.name + "'s leaderboard")
                .setDescription(str)
                .setThumbnail(interaction.guild.iconURL({
                    size: 1024
                }))
                .setColor(0xff00ff)
            try {
                await interaction.editReply({ embeds: [embed] })
            } catch(err) {
                await interaction.reply({ embeds: [embed] })
            }
        } catch (err) {
            console.err(err)
            try {
                await interaction.editReply({ content: "Something went wrong while getting the rank files :/", ephemeral: true })
            } catch(err) {
                await interaction.reply({ content: "Something went wrong while getting the rank files :/", ephemeral: true })
            }
        }
    },
}