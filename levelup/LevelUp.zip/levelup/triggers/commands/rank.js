const { SlashCommandBuilder, EmbedBuilder } = require('discord.js')
const fs = require("fs")
const console = require("../../../../Bot/consolelogger")
const levelXP = []

function calculateLevelXP() {
    const baseXP = 50
    const xpMultiplier = 1.25

    for (let level = 1; level <= 500; level++) {
        const xpRequired = Math.floor(baseXP * Math.pow(xpMultiplier, level - 1))
        levelXP.push(xpRequired)
    }
}

function getLevel(xp) {
    let level = 0
    while (true) {
        if (xp >= levelXP[level]) {
            level++
        } else {
            return level
        }
    }
}

calculateLevelXP()

module.exports = {
    data: new SlashCommandBuilder()
        .setName("rank")
        .setDescription("Check a rank")
        .addUserOption(option =>
            option
                .setName('user')
                .setDescription('The user to check')
                .setRequired(false)),
    async execute(interaction) {
        await interaction.deferReply()
        const user = interaction.options.getMember('user') ?? interaction.member
        try {
            if (!fs.existsSync("../../" + interaction.guild.id + ".json")) {
                fs.writeFileSync("../../" + interaction.guild.id + ".json", `{}`)
            }
            const data = require("../../" + String(interaction.guild.id) + ".json")
            delete require.cache[require.resolve("../../" + String(interaction.guild.id) + ".json")]
            if (!data[user.id]) {
                data[user.id] = {
                    level: 0,
                    xp: 0,
                    mul: 1,
                    name: ""
                }
            }
            const dataArray = Object.entries(data).map(([key, value]) => ({
                player: key,
                xp: value.xp,
            }))
            dataArray.sort((a, b) => b.xp - a.xp)
            const playerKeys = dataArray.map((player) => player.player)
            const embed = new EmbedBuilder()
                .setTitle(`${user.user.username}'s rank`)
                .setDescription(`**Rank:**\n${(Number(playerKeys.indexOf(String(user.id)))) + 1 ?? "Data not found"}\n\n**Level:**\n${getLevel(data[String(user.id)].xp)?? "Data not found"}\n\n**XP:**\n${data[String(user.id)].xp ?? "Data not found"}\n\n**XP til next level:**\n${Math.round((levelXP[getLevel(data[String(user.id)].xp)] - data[String(user.id)].xp) * 10) / 10}`)
                .setThumbnail(user.user.avatarURL({
                    size: 1024
                }))
                .setColor(0x00ffff)
            try {
                await interaction.editReply({ embeds: [embed] })
            } catch (err) {
                await interaction.reply({ embeds: [embed] })
            }
        } catch (err) {
            console.err(err)
            try {
                await interaction.editReply({ content: "Something went wrong while getting the rank files :/", ephemeral: true })
            } catch (err) {
                await interaction.reply({ content: "Something went wrong while getting the rank files :/", ephemeral: true })
            }
        }
    },
}