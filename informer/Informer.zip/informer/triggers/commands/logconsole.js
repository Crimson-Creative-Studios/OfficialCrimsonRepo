const { SlashCommandBuilder } = require('discord.js')
var console = require("../../../../Bot/consolelogger")
const config = require('../../../../config.json')

module.exports = {
	data: new SlashCommandBuilder()
		.setName("log")
		.setDescription("Log something in the console")
		.addStringOption(option =>
			option
				.setName('info')
				.setDescription('What to log')),
	async execute(interaction) {
		if (!interaction.member.roles.cache.some(r => r.name.startsWith(config.adminname))) {
			await interaction.reply("You do not have access to this command.")
		} else {
			const info = interaction.options.getString('info') ?? 'No information provided!'
			var user = interaction.user.tag
			console.custom({
				content: info,
				color: "cyan",
				name: "Log Command"
			})
			console.custom({
				content: user,
				color: "crimson",
				name: "User Action"
			})
			await interaction.reply("Information logged!")
		}
	},
}