const { EmbedBuilder, SlashCommandBuilder } = require("discord.js")

module.exports = {
    // The data needed to register slash commands to Discord.

    data: new SlashCommandBuilder()
        .setName("list_slash_commands")
        .setDescription(
            "List all commands that Crimson has registered"
        ),

    async execute(interaction) {
        const embed = new EmbedBuilder()
        .setColor("Random")
        .setTitle("List of all my slash commands")
        .setDescription("`" + interaction.client.commands
                              .map((command) => command.data.name)
                              .join("`, `") + "`")
        await interaction.reply({ embeds: [embed] })
    }
}