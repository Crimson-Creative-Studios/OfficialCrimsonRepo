const { ActionRowBuilder, Events, inlineCode, StringSelectMenuBuilder, EmbedBuilder } = require("discord.js")

const disabled = []
const tagCommands = [{
    label: "All Commands",
    description: "All commands known to Crimson",
    value: "allcommands",
    detail: "Placeholder, this statement is unused so eh",
}]
const tagCommandsOrigins = ["Crimson"]
const tagDescriptions = []
const noTags = []
var allCommands = ""

extensions.forEach((extension) => {
    var cfg = require(`../Extensions/${extension}/config.json`)
    var enabled = cfg.enabled
    if (enabled === "true") {
        var extensionstate = "enabled"
    } else {
        var extensionstate = "disabled"
    }
    var metadata = require(`../Extensions/${extension}/extension.json`)
    var dep = metadata.dependencies
    if (!extensionstate === "disabled") {
        for (const depe of dep) {
            if (!extensions.includes(depe) && !actsas.includes(depe)) {
                var extensionstate = "disabled"
            }
        }
    }
    if (extensionstate === "enabled") {
        try {
            var tags = require(`../Extensions/${extension}/tags.json`)
            for (var j of Object.keys(tags)) {
                var i = tags[j]
                if (i.enabled === "true") {
                    tagCommands.push(i)
                    tagCommandsOrigins.push(metadata.name)
                }
            }
        } catch (err) {
            tagDescriptions.push([
                metadata.name,
                ["This extension has no tag commands.\n"],
            ])
            noTags.push(extension)
        }

        if (!noTags.includes(extension)) {
            tagDescriptions.unshift([metadata.name, []])
        }
    } else {
        disabled.push(extension)
    }
})

for (const tag of tagCommands) {
    var exindex = tagCommands.indexOf(tag)
    var extension = tagCommandsOrigins[exindex]
    for (const des of tagDescriptions) {
        if (des[0] === extension) {
            var index = tagDescriptions.indexOf(des)
            var tempTagDescriptions = tagDescriptions[index]
            var tempTags = tempTagDescriptions[1]
            tempTags.push(tag.label)
            tempTagDescriptions[1] = tempTags
            tagDescriptions[index] = tempTagDescriptions
        }
    }
}

for (const des of tagDescriptions) {
    allCommands = allCommands + `${des[0]}:\n`
    var tags = des[1]
    for (const tag of tags) {
        allCommands = allCommands + inlineCode(tag) + "\n"
    }
    allCommands = allCommands + "\n"
}

client.on(Events.InteractionCreate, async (interaction) => {
    if (interaction.isStringSelectMenu() && interaction.customId === "commandSelector") {
        const row = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId("commandSelector")
                .setPlaceholder("Nothing")
                .addOptions(tagCommands)
        )

        const selected = interaction.values[0]
        if (selected === "allcommands") {
            const commandEmbed = new EmbedBuilder()
                .setColor(0xffffff)
                .setTitle("Crimson Tag Commands")
                .setDescription(allCommands)
            await interaction.update({ embeds: [commandEmbed], components: [row] })
        } else {
            var success = false
            for (const tag of tagCommands) {
                if (selected === tag.value) {
                    const commandEmbed = new EmbedBuilder()
                        .setColor(0xffffff)
                        .setTitle(`Crimson Tag Commands - ${tag.label}`)
                        .setDescription(tag.detail)
                    await interaction.update({
                        embeds: [commandEmbed],
                        components: [row],
                    })
                    var success = true
                }
            }
            if (success === false) {
                const commandEmbed = new EmbedBuilder()
                    .setColor(0xffffff)
                    .setTitle(`Crimson Tag Commands - Error`)
                    .setDescription(
                        "I was unable to get the information of that tag command, if it's from an extension then the developer likely has not set the tag commands file up properly!"
                    )
                await interaction.update({ embeds: [commandEmbed], components: [row] })
            }
        }
    } else return
})

client.on(Events.MessageCreate, async message => {
    if (message.toString() === "!ping") {
        const msg = await message.channel.send('Message to get latency')
        const apil = Math.round(client.ws.ping)
        var apilm
        if (apil < 0) {
            apilm = "Ping could not be found or rounded to an invalid number (a number below 0)"
        } else {
            apilm = String(apil) + "ms"
        }
        message.reply(`**Latency:**\n${msg.createdTimestamp - message.createdTimestamp}ms\n\n**API Latency:**\n${apilm}\n\n*Latency is the time it took to send a message when you sent a message.*`)
        msg.delete()
    }
})