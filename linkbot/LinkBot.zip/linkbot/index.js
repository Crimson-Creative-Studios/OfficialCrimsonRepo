const { WebhookClient, Events } = require('discord.js')
const config = require(resolvePath("./config.json"))

const webhookClient1 = new WebhookClient({ url: config.server1webhook })
const webhookClient2 = new WebhookClient({ url: config.server2webhook })

client.on(Events.MessageCreate, async message => {
    if (message.webhookId) return
    if (message.channelId === config.server1channelid || message.channelId === config.server2channelid) {
        const server = message.guild.id
        const username = message.author.username
        const avatar = message.author.avatarURL()
        if (server === config.server1id) {
            await webhookClient2.send({
                content: message.toString(),
                username: username,
                avatarURL: message.author.avatarURL(),
            })
        } else if (server === config.server2id) {
            await webhookClient1.send({
                content: message.toString(),
                username: username,
                avatarURL: message.author.avatarURL(),
            })
        } else {
            console.logger("Something went wrong... I may not have registered that server yet...", 'info')
        }
    }
})