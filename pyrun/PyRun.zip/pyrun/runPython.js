const { PythonShell } = require('python-shell');

var PyRun = function PyRun(path, args) {
    let options = {
        mode: 'text',
        pythonPath: 'python',
        pythonOptions: ['-u'],
        args: args
    };
    PythonShell.run(path, options).then(messages => {
        return results
    });
}

var MakePath = function MakePath(extension, dirname, file) {
    return dirname + extension + "/" + file
}

var StartScript = function StartScript(path) {
    let options = {
        mode: 'text',
        pythonPath: 'python',
        pythonOptions: ['-u']
    };
    return new PythonShell(path, options);
}

var RunStr = function RunStr(string, callback) {
    PythonShell.runString(string, null).then(callback);
}

module.exports = {
    PyRun,
    MakePath,
    StartScript,
    RunStr
}