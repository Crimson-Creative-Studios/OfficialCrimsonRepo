var PyRun = async function PyRun(file, args) {
    const PythonShell = require('python-shell').PythonShell;
    var options = {
        mode: 'text',
        pythonPath: 'python',
        pythonOptions: ['-u'],
        args: args
    };
    var result = PythonShell.run(file, options, function (err, results) {
        if (err)
            console.logger(err, 'error')
        return results
    });
    return result
}

var MakePath = async function MakePath(extension, dirname, file) {
    var path = dirname+"/../Extensions/"+extension+"/"+file
    return path
}

module.exports = {
    PyRun,
    MakePath
}