const { embedOptions } = require('../../config')
const { notInVoiceChannel } = require('../../utils/validation/voiceChannelValidator')
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js')
const { useQueue } = require('discord-player')

module.exports = {
    isNew: true,
    isBeta: false,
    data: new SlashCommandBuilder()
        .setName('stop')
        .setDescription('Stop playing audio and clear the track queue.')
        .setDMPermission(false)
        .setNSFW(false),
    execute: async (interaction) => {
        await interaction.deferReply()
        if (await notInVoiceChannel(interaction)) {
            return
        }

        const queue = useQueue(interaction.guild.id)

        if (!queue) {
            await interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setDescription(
                            `**${embedOptions.icons.warning} Oops!**\n_Hmm.._ It seems I am not in a voice channel!`
                        )
                        .setColor(embedOptions.colors.warning)
                ]
            })
            return
        }

        if (!queue.deleted) {
            queue.setRepeatMode(0)
            queue.clear()
            queue.node.stop()
        }

        await interaction.editReply({
            embeds: [
                new EmbedBuilder()
                    .setAuthor({
                        name: interaction.member.nickname || interaction.user.username,
                        iconURL: interaction.user.avatarURL()
                    })
                    .setDescription(
                        `**${embedOptions.icons.success} Stopped playing**\nStopped playing audio and cleared the track queue.\n\nTo play more music, use the **\`/play\`** command!`
                    )
                    .setColor(embedOptions.colors.success)
            ]
        })
        return
    }
}