const { ActionRowBuilder, ButtonBuilder, EmbedBuilder } = require('discord.js')
const { YouTubeExtractor, SpotifyExtractor, SoundCloudExtractor, AttachmentExtractor } = require('@discord-player/extractor')
const { Player } = require("discord-player")

global.client.config = {
    opt: {
        DJ: {
            enabled: false,
            roleName: '',
            commands: []
        },
        maxVol: 100,
        leaveOnEnd: true,
        loopMessage: false,
        spotifyBridge: true,
        defaultvolume: 75,
        discordPlayer: {
            ytdlOptions: {
                quality: 'highestaudio',
                highWaterMark: 1 << 25
            }
        }
    }
}

global.player = new Player(client, {
    ytdlOptions: {
        quality: 'highestaudio',
        highWaterMark: 1 << 25
    }
})

global.player.extractors.register(YouTubeExtractor)
global.player.extractors.register(SpotifyExtractor)
global.player.extractors.register(SoundCloudExtractor)
global.player.extractors.register(AttachmentExtractor)

global.player.on('error', (queue, error) => {
    console.log(`Error emitted from the queue ${error.message}`);
});

global.player.on('connectionError', (queue, error) => {
    console.log(`Error emitted from the connection ${error.message}`);
});

global.player.on('trackStart', (queue, track) => {
    if (!client.config.opt.loopMessage && queue.repeatMode !== 0) return
    const embed = new EmbedBuilder()
        .setAuthor({ name: `Started playing ${track.title} in ${queue.connection.channel.name} 🎧`, iconURL: track.requestedBy.avatarURL() })
        .setColor('#13f857')

    const back = new ButtonBuilder()
        .setLabel('Back')
        .setCustomId(JSON.stringify({ ffb: 'back' }))
        .setStyle('Primary')

    const skip = new ButtonBuilder()
        .setLabel('Skip')
        .setCustomId(JSON.stringify({ ffb: 'skip' }))
        .setStyle('Primary')

    const resumepause = new ButtonBuilder()
        .setLabel('Resume & Pause')
        .setCustomId(JSON.stringify({ ffb: 'resume&pause' }))
        .setStyle('Danger')

    const loop = new ButtonBuilder()
        .setLabel('Loop')
        .setCustomId(JSON.stringify({ ffb: 'loop' }))
        .setStyle('Secondary')

    const queuebutton = new ButtonBuilder()
        .setLabel('Queue')
        .setCustomId(JSON.stringify({ ffb: 'queue' }))
        .setStyle('Secondary')

    const row1 = new ActionRowBuilder().addComponents(back, loop, resumepause, queuebutton, skip)
    queue.metadata.send({ embeds: [embed], components: [row1] })
})

global.player.on('trackAdd', (queue, track) => {
    queue.metadata.send(`Track ${track.title} added in the queue ✅`)
})

global.player.on('botDisconnect', (queue) => {
    queue.metadata.send('I was manually disconnected from the voice channel, clearing queue... ❌')
})

global.player.on('channelEmpty', (queue) => {
    queue.metadata.send('Nobody is in the voice channel, leaving the voice channel... ❌')
})

global.player.on('queueEnd', (queue) => {
    queue.metadata.send('I finished reading the whole queue ✅')
})

global.player.on('tracksAdd', (queue, tracks) => {
    queue.metadata.send(`All the songs in playlist added into the queue ✅`)
})