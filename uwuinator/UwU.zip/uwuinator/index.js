const { Events } = require('discord.js')
const uwuifyer = require("uwuifyer");

client.on(Events.MessageCreate, async message => {
    if(message.author.bot) return;
    var messagestr = message.toString()
    const owoifiedText = uwuifyer(messagestr);
    message.channel.send(owoifiedText)
})